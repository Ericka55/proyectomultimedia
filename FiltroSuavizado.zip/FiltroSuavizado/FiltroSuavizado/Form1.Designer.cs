﻿namespace FiltroSuavizado
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBoxOriginal = new PictureBox();
            pictureBoxResultado = new PictureBox();
            btnCargar = new Button();
            btnAplicarFiltro = new Button();
            lblInfo = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBoxOriginal).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxResultado).BeginInit();
            SuspendLayout();
            // 
            // pictureBoxOriginal
            // 
            pictureBoxOriginal.BorderStyle = BorderStyle.FixedSingle;
            pictureBoxOriginal.Location = new Point(40, 37);
            pictureBoxOriginal.Name = "pictureBoxOriginal";
            pictureBoxOriginal.Size = new Size(233, 193);
            pictureBoxOriginal.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxOriginal.TabIndex = 0;
            pictureBoxOriginal.TabStop = false;
            // 
            // pictureBoxResultado
            // 
            pictureBoxResultado.BorderStyle = BorderStyle.FixedSingle;
            pictureBoxResultado.Location = new Point(40, 245);
            pictureBoxResultado.Name = "pictureBoxResultado";
            pictureBoxResultado.Size = new Size(233, 193);
            pictureBoxResultado.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxResultado.TabIndex = 1;
            pictureBoxResultado.TabStop = false;
            // 
            // btnCargar
            // 
            btnCargar.Location = new Point(314, 61);
            btnCargar.Name = "btnCargar";
            btnCargar.Size = new Size(140, 46);
            btnCargar.TabIndex = 2;
            btnCargar.Text = "Cargar Imagen";
            btnCargar.UseVisualStyleBackColor = true;
            btnCargar.Click += btnCargar_Click;
            // 
            // btnAplicarFiltro
            // 
            btnAplicarFiltro.Location = new Point(314, 133);
            btnAplicarFiltro.Name = "btnAplicarFiltro";
            btnAplicarFiltro.Size = new Size(140, 46);
            btnAplicarFiltro.TabIndex = 3;
            btnAplicarFiltro.Text = "Aplicar filtro";
            btnAplicarFiltro.UseVisualStyleBackColor = true;
            btnAplicarFiltro.Click += btnAplicarFiltro_Click;
            // 
            // lblInfo
            // 
            lblInfo.AutoSize = true;
            lblInfo.Location = new Point(323, 250);
            lblInfo.Name = "lblInfo";
            lblInfo.Size = new Size(177, 25);
            lblInfo.TabIndex = 4;
            lblInfo.Text = "Esperando Imagen..";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(11F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblInfo);
            Controls.Add(btnAplicarFiltro);
            Controls.Add(btnCargar);
            Controls.Add(pictureBoxResultado);
            Controls.Add(pictureBoxOriginal);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pictureBoxOriginal).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxResultado).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBoxOriginal;
        private PictureBox pictureBoxResultado;
        private Button btnCargar;
        private Button btnAplicarFiltro;
        private Label lblInfo;
    }
}
