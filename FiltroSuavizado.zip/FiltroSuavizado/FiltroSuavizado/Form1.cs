using System;
using System.Drawing;
using System.Windows.Forms;

namespace FiltroSuavizado
{
    public partial class Form1 : Form
    {
        private Bitmap? imagenOriginal;
        public Form1()
        {
            InitializeComponent();

            pictureBoxOriginal.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxResultado.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void btnCargar_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();

            ofd.Filter = "Imagenes|*.jpg;*.jpeg;*.png;*.bmp";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                imagenOriginal = new Bitmap(ofd.FileName);

                pictureBoxOriginal.Image = imagenOriginal;

                lblInfo.Text =
                    $"Imagen cargada: {imagenOriginal.Width} x {imagenOriginal.Height}";
            }
        }

       
        private void btnAplicarFiltro_Click(object sender, EventArgs e)

        {
            MessageBox.Show("Entr� al filtro");
            if (imagenOriginal == null)
            {
                MessageBox.Show("Primero cargue una imagen");
                return;
            }

            Bitmap salida =
                new Bitmap(
                    imagenOriginal.Width,
                    imagenOriginal.Height);

            for (int x = 1; x < imagenOriginal.Width - 1; x++)
            {
                for (int y = 1; y < imagenOriginal.Height - 1; y++)
                {
                    int sumaR = 0;
                    int sumaG = 0;
                    int sumaB = 0;

                    for (int i = -1; i <= 1; i++)
                    {
                        for (int j = -1; j <= 1; j++)
                        {
                            Color vecino =
                                imagenOriginal.GetPixel(
                                    x + i,
                                    y + j);

                            sumaR += vecino.R;
                            sumaG += vecino.G;
                            sumaB += vecino.B;
                        }
                    }

                    int promedioR = sumaR / 9;
                    int promedioG = sumaG / 9;
                    int promedioB = sumaB / 9;

                    Color nuevoColor =
                        Color.FromArgb(
                            promedioR,
                            promedioG,
                            promedioB);

                    salida.SetPixel(
                        x,
                        y,
                        nuevoColor);
                }
            }

            for (int x = 0; x < imagenOriginal.Width; x++)
            {
                salida.SetPixel(
                    x,
                    0,
                    imagenOriginal.GetPixel(x, 0));

                salida.SetPixel(
                    x,
                    imagenOriginal.Height - 1,
                    imagenOriginal.GetPixel(
                        x,
                        imagenOriginal.Height - 1));
            }

            for (int y = 0; y < imagenOriginal.Height; y++)
            {
                salida.SetPixel(
                    0,
                    y,
                    imagenOriginal.GetPixel(0, y));

                salida.SetPixel(
                    imagenOriginal.Width - 1,
                    y,
                    imagenOriginal.GetPixel(
                        imagenOriginal.Width - 1,
                        y));
            }

            MessageBox.Show("Filtro terminado");
            pictureBoxResultado.Image = salida;

            lblInfo.Text =
                "Filtro de suavizado 3x3 aplicado correctamente";
        }

        private void btnAplicarFiltro_Click_1(object sender, EventArgs e)
        {

        }
    }
}